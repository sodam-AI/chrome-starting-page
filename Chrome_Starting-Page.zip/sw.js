const CACHE = 'dashboard-v72';
const PRECACHE = ['/', '/style.css', '/script.js'];

self.addEventListener('install', e => {
    e.waitUntil(caches.open(CACHE).then(c => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
    e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
    if (e.request.url.includes('/api/')) return; // Don't cache API calls
    e.respondWith(
        fetch(e.request).then(r => {
            if (r.ok) { const c = r.clone(); caches.open(CACHE).then(cache => cache.put(e.request, c)); }
            return r;
        }).catch(() => caches.match(e.request))
    );
});
