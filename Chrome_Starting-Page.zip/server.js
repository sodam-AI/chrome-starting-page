const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const PORT = 1111;
const HOST = '127.0.0.1'; // Security: localhost only
const DIR = __dirname;
const MAX_BODY = 10 * 1024 * 1024;
const MAX_ERROR_LOG = 10 * 1024 * 1024; // 10MB error log limit
const DATA = path.join(DIR, 'data');

// === Static File Cache (raw + pre-compressed gzip) ===
const _fileCache = new Map();
const CACHE_MAX_AGE = 300 * 1000; // 5 min cache
const crypto = require('crypto');
function getCachedFile(fp, wantGzip) {
    const cached = _fileCache.get(fp);
    if (cached && Date.now() - cached.time < CACHE_MAX_AGE) {
        return wantGzip && cached.gzip ? { data: cached.gzip, etag: cached.etag, gzipped: true } : { data: cached.data, etag: cached.etag, gzipped: false };
    }
    try {
        const data = fs.readFileSync(fp);
        const etag = '"' + crypto.createHash('md5').update(data).digest('hex').slice(0, 16) + '"';
        const entry = { data, etag, time: Date.now(), gzip: null };
        // Pre-compress text files
        const ext = path.extname(fp).toLowerCase();
        if (['.html','.css','.js','.json','.svg','.webmanifest'].includes(ext)) {
            try { entry.gzip = zlib.gzipSync(data, { level: 6 }); } catch {}
        }
        _fileCache.set(fp, entry);
        return wantGzip && entry.gzip ? { data: entry.gzip, etag, gzipped: true } : { data, etag, gzipped: false };
    } catch { return null; }
}
function clearFileCache() { _fileCache.clear(); }
// Pre-load critical files on startup
function preloadCache() {
    ['index.html','style.css','script.js','manifest.webmanifest','sw.js'].forEach(f => {
        try { getCachedFile(path.join(DIR, f), true); } catch {}
    });
}

const MIME = {
    '.html':'text/html','.css':'text/css','.js':'text/javascript',
    '.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg',
    '.gif':'image/gif','.svg':'image/svg+xml','.json':'application/json',
    '.ico':'image/x-icon','.webp':'image/webp','.woff2':'font/woff2',
    '.woff':'font/woff','.webmanifest':'application/manifest+json'
};

// === Write Lock: prevent race conditions on concurrent JSON writes ===
const _writeLocks = new Map();
async function acquireWriteLock(file) {
    while (_writeLocks.has(file)) {
        await _writeLocks.get(file);
    }
    let resolve;
    const p = new Promise(r => { resolve = r; });
    p._resolve = resolve;
    _writeLocks.set(file, p);
}
function releaseWriteLock(file) {
    const p = _writeLocks.get(file);
    _writeLocks.delete(file);
    if (p && p._resolve) p._resolve();
}

function safePath(url) {
    const d = decodeURIComponent(url.split('?')[0]);
    const r = path.resolve(DIR, '.' + d);
    return r.startsWith(DIR) ? r : null;
}
// Sanitize uploaded filenames: strip path separators and dangerous chars
function sanitizeFilename(name) {
    return name.replace(/[\/\\:*?"<>|]/g, '_').replace(/\.\./g, '_').slice(0, 100);
}
function readBody(req, cb) {
    const chunks = []; let s = 0;
    req.on('data', c => { s += c.length; if (s > MAX_BODY) { req.destroy(); return cb(new Error('Too large')); } chunks.push(c); });
    req.on('end', () => cb(null, Buffer.concat(chunks).toString('utf8')));
    req.on('error', cb);
}
function json(res, code, data) {
    if (res.writableEnded) return; // Guard: prevent write after end
    res.writeHead(code, { 'Content-Type':'application/json', 'Cache-Control':'no-cache' });
    res.end(JSON.stringify(data));
}
function rJson(file, fb) {
    try {
        const raw = fs.readFileSync(file, 'utf8');
        if (!raw || !raw.trim()) return fb; // Guard: empty file
        const parsed = JSON.parse(raw);
        return parsed !== null && parsed !== undefined ? parsed : fb;
    } catch { return fb; }
}
function wJson(file, data) {
    try {
        const json = JSON.stringify(data, null, 2);
        // Validate JSON can be re-parsed before writing (safety check)
        JSON.parse(json);
        // Atomic write: write to temp then rename (prevents corruption on crash)
        const tmp = file + '.tmp';
        fs.writeFileSync(tmp, json, 'utf8');
        fs.renameSync(tmp, file);
    } catch (e) {
        // Fallback: direct write if rename fails
        try { fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8'); }
        catch (e2) { console.error('[Write Error]', file, e2.message); }
        // Clean up orphaned tmp file
        try { if (fs.existsSync(file + '.tmp')) fs.unlinkSync(file + '.tmp'); } catch {}
    }
}
function ensureDir(d) { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); }

// --- Auto Backup ---
let backupTimer = null;
function startAutoBackup() {
    if (backupTimer) clearInterval(backupTimer);
    const cfg = rJson(path.join(DATA, 'config.json'), {});
    const hours = cfg.backupIntervalHours || 24;
    // Defer first backup 60s to avoid blocking initial requests
    setTimeout(() => { doBackup(); backupTimer = setInterval(doBackup, hours * 3600 * 1000); }, 60000);
}
function doBackup() {
    try {
        ensureDir(path.join(DATA, 'backups'));
        const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const backupData = {
            _backup_version: '7.3', _backup_date: new Date().toISOString(),
            bookmarks: rJson(path.join(DATA, 'bookmarks.json'), {}),
            notes: rJson(path.join(DATA, 'notes.json'), { notes: [] }),
            config: rJson(path.join(DATA, 'config.json'), {}),
            todos: rJson(path.join(DATA, 'todos.json'), { items: [] }),
            ddays: rJson(path.join(DATA, 'ddays.json'), { items: [] }),
            usage: rJson(path.join(DATA, 'usage.json'), {}),
            trash: rJson(path.join(DATA, 'trash.json'), {items: []}),
            events: rJson(path.join(DATA, 'events.json'), {items: []}),
            'pomo-stats': rJson(path.join(DATA, 'pomo-stats.json'), {sessions: []})
        };
        wJson(path.join(DATA, 'backups', `backup-${ts}.json`), backupData);
        // Smart retention: 7 days all, 8-30 days keep 1/day, 30+ days delete
        const now = Date.now();
        const DAY = 86400000;
        const backups = fs.readdirSync(path.join(DATA, 'backups'))
            .filter(f => f.startsWith('backup-') && f.endsWith('.json'))
            .sort();
        const toDelete = [];
        const dayBuckets = {};
        backups.forEach(f => {
            const m = f.match(/backup-(\d{4})-(\d{2})-(\d{2})/);
            if (!m) return;
            const fileDate = new Date(`${m[1]}-${m[2]}-${m[3]}`);
            const age = (now - fileDate.getTime()) / DAY;
            if (age > 30) { toDelete.push(f); }
            else if (age > 7) {
                const dayKey = `${m[1]}-${m[2]}-${m[3]}`;
                if (!dayBuckets[dayKey]) dayBuckets[dayKey] = [];
                dayBuckets[dayKey].push(f);
            }
        });
        // For 8-30 day range: keep only newest per day
        Object.values(dayBuckets).forEach(files => {
            files.sort();
            files.slice(0, -1).forEach(f => toDelete.push(f));
        });
        toDelete.forEach(f => {
            try { fs.unlinkSync(path.join(DATA, 'backups', f)); } catch(e) {}
        });
        // Hard cap at 50 total as safety net
        const remaining = fs.readdirSync(path.join(DATA, 'backups')).filter(f => f.startsWith('backup-')).sort();
        while (remaining.length > 50) {
            try { fs.unlinkSync(path.join(DATA, 'backups', remaining.shift())); } catch(e) {}
        }
    } catch (e) { console.error('[Backup]', e.message); }
}

// --- Multipart Parser (Buffer-safe) ---
function parseMultipart(raw, boundary) {
    const parts = [];
    const boundaryBuf = Buffer.from('--' + boundary);
    let start = 0;
    while (true) {
        const bStart = raw.indexOf(boundaryBuf, start);
        if (bStart === -1) break;
        const bEnd = bStart + boundaryBuf.length;
        // Check for closing boundary (--)
        if (raw[bEnd] === 0x2D && raw[bEnd + 1] === 0x2D) break;
        // Find next boundary
        const nextB = raw.indexOf(boundaryBuf, bEnd);
        if (nextB === -1) break;
        const segment = raw.slice(bEnd, nextB);
        // Find header end (\r\n\r\n)
        const hEnd = segment.indexOf('\r\n\r\n');
        if (hEnd === -1) { start = nextB; continue; }
        const header = segment.slice(0, hEnd).toString('utf8');
        const fn = header.match(/filename="(.+?)"/);
        if (!fn) { start = nextB; continue; }
        // Body: skip \r\n\r\n (4 bytes), trim trailing \r\n
        let body = segment.slice(hEnd + 4);
        if (body.length >= 2 && body[body.length - 2] === 0x0D && body[body.length - 1] === 0x0A) {
            body = body.slice(0, body.length - 2);
        }
        parts.push({ filename: fn[1], data: body });
        start = nextB;
    }
    return parts;
}

// --- Server ---
const server = http.createServer((req, res) => {
    const url = req.url.split('?')[0];
    const m = req.method;
    const query = new URL(req.url, `http://localhost:${PORT}`).searchParams;

    // === JSON CRUD APIs ===
    const apis = {
        '/api/bookmarks': { f:'bookmarks.json', fb:{}, v:d=>typeof d==='object'&&d!==null },
        '/api/notes': { f:'notes.json', fb:{notes:[]}, v:d=>d&&(Array.isArray(d.notes)||typeof d.notes==='object') },
        '/api/config': { f:'config.json', fb:{}, v:d=>typeof d==='object' },
        '/api/todos': { f:'todos.json', fb:{items:[]}, v:d=>d&&Array.isArray(d.items) },
        '/api/ddays': { f:'ddays.json', fb:{items:[]}, v:d=>d&&Array.isArray(d.items) },
        '/api/usage': { f:'usage.json', fb:{}, v:d=>typeof d==='object' },
        '/api/events': { f:'events.json', fb:{items:[]}, v:d=>d&&Array.isArray(d.items) },
        '/api/trash': { f:'trash.json', fb:{items:[]}, v:d=>d&&Array.isArray(d.items) },
        '/api/pomo-stats': { f:'pomo-stats.json', fb:{sessions:[]}, v:d=>d&&Array.isArray(d.sessions) },
    };

    const api = apis[url];
    if (api) {
        const fp = path.join(DATA, api.f);
        if (m === 'GET') return json(res, 200, rJson(fp, api.fb));
        if (m === 'POST') {
            readBody(req, async (err, body) => {
                if (err) return json(res, 413, { error:'Too large' });
                try {
                    const p = JSON.parse(body);
                    if (!api.v(p)) throw new Error('Invalid');
                    await acquireWriteLock(fp);
                    try { wJson(fp, p); } finally { releaseWriteLock(fp); }
                    if (url === '/api/config') startAutoBackup();
                    json(res, 200, { success:true });
                } catch(e) { json(res, 400, { error:'Invalid JSON' }); }
            });
            return;
        }
    }

    // === Usage Track ===
    if (url === '/api/usage/track' && m === 'POST') {
        readBody(req, async (err, body) => {
            if (err) return json(res, 413, { error:'Too large' });
            try {
                const { key } = JSON.parse(body);
                if (!key || typeof key !== 'string' || key.length > 500) throw new Error('No key');
                const fp = path.join(DATA, 'usage.json');
                await acquireWriteLock(fp);
                try {
                    const usage = rJson(fp, {});
                    if (!usage[key]) usage[key] = { count: 0, lastUsed: null, hourly: {}, history: [] };
                    usage[key].count++;
                    const now = new Date();
                    usage[key].lastUsed = now.toISOString();
                    // Hourly tracking for time-based sorting
                    const h = now.getHours().toString();
                    if (!usage[key].hourly) usage[key].hourly = {};
                    usage[key].hourly[h] = (usage[key].hourly[h] || 0) + 1;
                    // History for heatmap (keep last 90 days)
                    if (!usage[key].history) usage[key].history = [];
                    usage[key].history.push(now.toISOString());
                    if (usage[key].history.length > 500) usage[key].history = usage[key].history.slice(-500);
                    wJson(fp, usage);
                } finally { releaseWriteLock(fp); }
                json(res, 200, { success: true });
            } catch { json(res, 400, { error:'Invalid' }); }
        });
        return;
    }

    // === Export ===
    if (url === '/api/export' && m === 'GET') {
        const data = {
            _export_version: '7.2', _export_date: new Date().toISOString(),
            bookmarks: rJson(path.join(DATA,'bookmarks.json'),{}),
            notes: rJson(path.join(DATA,'notes.json'),{notes:[]}),
            config: rJson(path.join(DATA,'config.json'),{}),
            todos: rJson(path.join(DATA,'todos.json'),{items:[]}),
            ddays: rJson(path.join(DATA,'ddays.json'),{items:[]}),
            usage: rJson(path.join(DATA,'usage.json'),{}),
            trash: rJson(path.join(DATA,'trash.json'),{items:[]}),
            events: rJson(path.join(DATA,'events.json'),{items:[]}),
            'pomo-stats': rJson(path.join(DATA,'pomo-stats.json'),{sessions:[]})
        };
        res.writeHead(200, { 'Content-Type':'application/json',
            'Content-Disposition':`attachment; filename="dashboard-backup-${new Date().toISOString().slice(0,10)}.json"` });
        res.end(JSON.stringify(data, null, 2));
        return;
    }

    // === Import ===
    if (url === '/api/import' && m === 'POST') {
        readBody(req, async (err, body) => {
            if (err) return json(res, 413, { error:'Too large' });
            try {
                const d = JSON.parse(body);
                if (!d._export_version && !d._backup_version) throw new Error('Not valid');
                // Create safety backup before import
                try { doBackup(); } catch {}
                if (d.bookmarks) wJson(path.join(DATA,'bookmarks.json'), d.bookmarks);
                if (d.notes) wJson(path.join(DATA,'notes.json'), d.notes);
                if (d.config) wJson(path.join(DATA,'config.json'), d.config);
                if (d.todos) wJson(path.join(DATA,'todos.json'), d.todos);
                if (d.ddays) wJson(path.join(DATA,'ddays.json'), d.ddays);
                if (d.usage) wJson(path.join(DATA,'usage.json'), d.usage);
                if (d.trash) wJson(path.join(DATA,'trash.json'), d.trash);
                if (d.events) wJson(path.join(DATA,'events.json'), d.events);
                if (d['pomo-stats']) wJson(path.join(DATA,'pomo-stats.json'), d['pomo-stats']);
                json(res, 200, { success:true });
            } catch (e) { json(res, 400, { error:e.message }); }
        });
        return;
    }

    // === Upload Background ===
    if (url === '/api/upload-background' && m === 'POST') {
        const chunks = []; let sz = 0; let destroyed = false;
        req.on('data', c => { sz += c.length; if (sz > MAX_BODY) { destroyed = true; req.destroy(); return; } chunks.push(c); });
        req.on('error', () => { destroyed = true; });
        req.on('end', () => {
            if (destroyed) return json(res, 413, { error: 'File too large' });
            try {
                const raw = Buffer.concat(chunks);
                const bm = (req.headers['content-type']||'').match(/boundary=(.+)/);
                if (!bm) return json(res, 400, { error:'No boundary' });
                const parts = parseMultipart(raw, bm[1]);
                if (!parts.length) return json(res, 400, { error:'No file' });
                const p = parts[0]; const ext = path.extname(sanitizeFilename(p.filename)).toLowerCase();
                if (!['.png','.jpg','.jpeg','.webp','.gif'].includes(ext)) return json(res, 400, { error:'Bad type' });
                ensureDir(path.join(DIR, 'assets'));
                const isSlide = query.get('slideshow') === 'true';
                const dest = isSlide ? 'slide_' + Date.now() + ext : 'background_custom' + ext;
                const destPath = path.join(DIR, 'assets', dest);
                // Verify dest is still within assets dir
                if (!destPath.startsWith(path.join(DIR, 'assets'))) return json(res, 400, { error:'Bad path' });
                fs.writeFileSync(destPath, p.data);
                if (!isSlide) {
                    const cfg = rJson(path.join(DATA,'config.json'), {});
                    cfg.backgroundImage = 'assets/' + dest;
                    wJson(path.join(DATA,'config.json'), cfg);
                }
                json(res, 200, { success:true, path:'assets/' + dest });
            } catch (e) { console.error('[Upload BG]', e.message); json(res, 500, { error:'Upload failed' }); }
        });
        return;
    }

    // === Upload Bookmark Icon ===
    if (url === '/api/upload-icon' && m === 'POST') {
        const chunks = []; let sz = 0; let destroyed = false;
        req.on('data', c => { sz += c.length; if (sz > MAX_BODY) { destroyed = true; req.destroy(); return; } chunks.push(c); });
        req.on('error', () => { destroyed = true; });
        req.on('end', () => {
            if (destroyed) return json(res, 413, { error: 'File too large' });
            try {
                const raw = Buffer.concat(chunks);
                const bm = (req.headers['content-type']||'').match(/boundary=(.+)/);
                if (!bm) return json(res, 400, { error:'No boundary' });
                const parts = parseMultipart(raw, bm[1]);
                if (!parts.length) return json(res, 400, { error:'No file' });
                const p = parts[0]; const ext = path.extname(sanitizeFilename(p.filename)).toLowerCase();
                if (!['.png','.jpg','.jpeg','.webp','.gif','.svg','.ico'].includes(ext)) return json(res, 400, { error:'Bad type' });
                ensureDir(path.join(DATA, 'icons'));
                const dest = 'icon_' + Date.now() + ext;
                const destPath = path.join(DATA, 'icons', dest);
                if (!destPath.startsWith(path.join(DATA, 'icons'))) return json(res, 400, { error:'Bad path' });
                fs.writeFileSync(destPath, p.data);
                json(res, 200, { success:true, path:'data/icons/' + dest });
            } catch (e) { console.error('[Upload Icon]', e.message); json(res, 500, { error:'Upload failed' }); }
        });
        return;
    }

    // === Profiles ===
    if (url === '/api/profiles' && m === 'GET') {
        ensureDir(path.join(DATA, 'profiles'));
        const profiles = fs.readdirSync(path.join(DATA, 'profiles')).filter(f => f.endsWith('.json')).map(f => f.replace('.json', ''));
        profiles.unshift('default');
        return json(res, 200, { profiles, active: rJson(path.join(DATA,'config.json'),{}).activeProfile || 'default' });
    }
    if (url === '/api/profiles/save' && m === 'POST') {
        readBody(req, (err, body) => {
            if (err) return json(res, 413, { error:'Too large' });
            try {
                const { name } = JSON.parse(body);
                if (!name || name === 'default') throw new Error('Invalid name');
                ensureDir(path.join(DATA, 'profiles'));
                const pd = { bookmarks: rJson(path.join(DATA,'bookmarks.json'),{}), notes: rJson(path.join(DATA,'notes.json'),{notes:[]}),
                    config: rJson(path.join(DATA,'config.json'),{}), todos: rJson(path.join(DATA,'todos.json'),{items:[]}), ddays: rJson(path.join(DATA,'ddays.json'),{items:[]}) };
                wJson(path.join(DATA, 'profiles', name + '.json'), pd);
                json(res, 200, { success:true });
            } catch (e) { json(res, 400, { error:e.message }); }
        });
        return;
    }
    if (url === '/api/profiles/load' && m === 'POST') {
        readBody(req, (err, body) => {
            if (err) return json(res, 413, { error:'Too large' });
            try {
                const { name } = JSON.parse(body);
                if (!name) throw new Error('No name');
                if (name === 'default') { const cfg = rJson(path.join(DATA,'config.json'),{}); cfg.activeProfile='default'; wJson(path.join(DATA,'config.json'),cfg); return json(res,200,{success:true}); }
                const pf = path.join(DATA, 'profiles', name + '.json');
                if (!fs.existsSync(pf)) throw new Error('Not found');
                const d = rJson(pf, null); if (!d) throw new Error('Invalid');
                if (d.bookmarks) wJson(path.join(DATA,'bookmarks.json'), d.bookmarks);
                if (d.notes) wJson(path.join(DATA,'notes.json'), d.notes);
                if (d.todos) wJson(path.join(DATA,'todos.json'), d.todos);
                if (d.ddays) wJson(path.join(DATA,'ddays.json'), d.ddays);
                if (d.config) { d.config.activeProfile=name; wJson(path.join(DATA,'config.json'), d.config); }
                json(res, 200, { success:true });
            } catch (e) { json(res, 400, { error:e.message }); }
        });
        return;
    }
    if (url === '/api/profiles/delete' && m === 'POST') {
        readBody(req, (err, body) => {
            if (err) return json(res, 413, { error:'Too large' });
            try {
                const { name } = JSON.parse(body); if (!name || name === 'default') throw new Error('Cannot');
                const pf = path.join(DATA, 'profiles', name + '.json');
                if (fs.existsSync(pf)) fs.unlinkSync(pf);
                json(res, 200, { success:true });
            } catch (e) { json(res, 400, { error:e.message }); }
        });
        return;
    }

    // === Health / Backups ===
    if (url === '/api/health' && m === 'GET') return json(res, 200, { status:'ok', version:'7.2', uptime: process.uptime(), timestamp: Date.now(), memory: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + 'MB' });
    if (url === '/api/backups' && m === 'GET') {
        ensureDir(path.join(DATA, 'backups'));
        return json(res, 200, { backups: fs.readdirSync(path.join(DATA, 'backups')).filter(f => f.endsWith('.json')).sort().reverse() });
    }

    // === Trash ===
    const trashFile = path.join(DATA, 'trash.json');
    if (url === '/api/trash' && m === 'GET') return json(res, 200, rJson(trashFile, { items: [] }));
    if (url === '/api/trash' && m === 'POST') {
        readBody(req, async (err, body) => {
            if (err) return json(res, 413, { error:'Too large' });
            try {
                const p = JSON.parse(body);
                if (!p || !Array.isArray(p.items)) throw new Error('Invalid');
                // Auto-clean items older than 30 days
                const cutoff = Date.now() - 30 * 24 * 3600 * 1000;
                p.items = p.items.filter(i => i && i.deletedAt && new Date(i.deletedAt).getTime() > cutoff);
                await acquireWriteLock(trashFile);
                try { wJson(trashFile, p); } finally { releaseWriteLock(trashFile); }
                json(res, 200, { success: true });
            } catch { json(res, 400, { error:'Invalid' }); }
        });
        return;
    }

    // === Static Files (cached + pre-gzip + ETag) ===
    const fp = safePath(url === '/' ? '/index.html' : url);
    if (!fp) { res.writeHead(403); res.end('Forbidden'); return; }
    const ct = MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream';
    const ae = req.headers['accept-encoding'] || '';
    const wantGzip = ae.includes('gzip');
    const result = getCachedFile(fp, wantGzip);
    if (!result) { res.writeHead(404); res.end('404'); return; }
    // ETag: skip sending body if browser already has it
    if (req.headers['if-none-match'] === result.etag) {
        res.writeHead(304, { 'ETag': result.etag, 'Connection': 'keep-alive' });
        res.end();
        return;
    }
    const headers = {
        'Content-Type': ct,
        'ETag': result.etag,
        'X-Content-Type-Options': 'nosniff',
        'Connection': 'keep-alive',
        'Keep-Alive': 'timeout=30'
    };
    if (ct.startsWith('image/') || ct.startsWith('font/')) {
        headers['Cache-Control'] = 'public, max-age=86400';
    } else {
        headers['Cache-Control'] = 'public, max-age=10, must-revalidate';
    }
    if (result.gzipped) headers['Content-Encoding'] = 'gzip';
    headers['Content-Length'] = result.data.length;
    res.writeHead(200, headers);
    res.end(result.data);
});

server.keepAliveTimeout = 30000;
server.headersTimeout = 35000;
server.listen(PORT, HOST, () => { console.log(`[Dashboard v7.3] http://${HOST}:${PORT}/`); preloadCache(); startAutoBackup(); });

// === Graceful Shutdown ===
function gracefulShutdown(signal) {
    console.log(`\n[Server] ${signal} received. Shutting down gracefully...`);
    if (backupTimer) clearInterval(backupTimer);
    try { doBackup(); console.log('[Server] Final backup saved.'); } catch (e) { console.error('[Server] Backup failed:', e.message); }
    server.close(() => {
        console.log('[Server] HTTP server closed.');
        process.exit(0);
    });
    // Force exit after 5 seconds if server.close() hangs
    setTimeout(() => { console.error('[Server] Forced exit after timeout.'); process.exit(1); }, 5000);
}
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

// === Uncaught Error Handlers ===
function appendErrorLog(msg) {
    try {
        const logFile = path.join(DIR, 'server.error.log');
        // Rotate log if too large
        try { const stat = fs.statSync(logFile); if (stat.size > MAX_ERROR_LOG) fs.renameSync(logFile, logFile + '.old'); } catch {}
        fs.appendFileSync(logFile, `[${new Date().toISOString()}] ${msg}\n`);
    } catch {}
}
process.on('uncaughtException', (err) => {
    console.error('[FATAL] Uncaught exception:', err.message);
    appendErrorLog(`UNCAUGHT: ${err.stack}`);
});
process.on('unhandledRejection', (reason) => {
    console.error('[WARN] Unhandled rejection:', reason);
    appendErrorLog(`REJECTION: ${reason}`);
});
